var config = { 
      config: {
            mixins: {
                 'mage/validation': {
                       'Syncitgroup_Sgform/js/validation-mixin': true
                 }
          }
   }
}