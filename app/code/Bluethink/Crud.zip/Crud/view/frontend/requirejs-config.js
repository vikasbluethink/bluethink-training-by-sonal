var config = {
    config: {
        mixins: {
            'mage/validation': {
                'Bluethink_Crud/js/validation-mixin': true
                
            }
        }
    }
}
