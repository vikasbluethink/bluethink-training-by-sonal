var config = {
    config: {
        mixins: {
            'mage/validation': {
                'Bluethink_FormValidation/js/validation-mixin': true
                
            }
        }
    }
}
