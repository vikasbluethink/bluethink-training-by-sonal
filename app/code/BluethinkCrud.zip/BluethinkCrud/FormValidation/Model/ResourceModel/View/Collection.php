<?php
namespace Bluethink\FormValidation\Model\ResourceModel\View;

use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * Remittance File Collection Constructor
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Bluethink\FormValidation\Model\View::class, \Bluethink\FormValidation\Model\ResourceModel\View::class);
    }
}